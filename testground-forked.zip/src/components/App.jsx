import React from "react";

function strike() {
  document.getElementById("root").style.textDecoration = "line-through";
}
function unStrike() {
  document.getElementById("root").style.textDecoration = null;
}

function App() {
  return (
    <div>
      <p>Buy Milk</p>
      <button onClick={strike}>Change to strike through</button>
      <button onClick={unStrike}>Change Back</button>
    </div>
  );
}
// var isDone = false;

// const strikeThrough = { textDecoration: "line-through" };

// <p style={isDone ? strikeThrough : null}>Buy beer</p>;

export default App;
